import React from 'react'
import PortfolioPage from './PortfolioPage'

export default function App(){
  return <PortfolioPage/>
}
